Los ficheros mandel-tar* hace referencia al punto 2

Los ficheros mandel-omp-3* hace referencia al punto 3 y los subapartados que pertecene para 

Los ficheros mandel-omp_point/row_ntasks.c son codigo de la parte opcional 